export const appStoreLinks = {
  ios: "https://apps.apple.com/us/app/daimo/id6459700343",
  android: "https://play.google.com/store/apps/details?id=com.daimo",
};
