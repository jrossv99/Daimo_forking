# `@daimo/contract`

Provides all contract metadata needed by Daimo, across all supported chains.

This includes ABIs and addresses. It includes our own contracts as well as
third-party contracts, eg. the stablecoin and paymaster contracts.
