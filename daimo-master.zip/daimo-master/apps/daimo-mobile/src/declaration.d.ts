declare module "*.png";
declare module "*.mp4";
