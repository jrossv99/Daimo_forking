export interface StoredModel {
  storageVersion: number;
}
