export enum BankTransferOptions {
  Deposit = "Deposit",
  Withdraw = "Withdraw",
}
