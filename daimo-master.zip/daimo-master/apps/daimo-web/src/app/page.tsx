import { HomePage } from "./HomePage";

export default function HomePageWrap() {
  return <HomePage />;
}
