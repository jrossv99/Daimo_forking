# Bug Bounties with Immunefi

## Overview

This bug bounty document verifies that Daimo hosts a bug bounty on Immunefi at the address [https://immunefi.com/bounty/daimo/](https://immunefi.com/bounty/daimo/).

See the bounty page at Immunefi for more details on accepted vulnerabilities, payout amounts, and rules of participation.

Users who violate the rules of participation will not receive bug bounty payouts and may be temporarily suspended or banned from the bug bounty program.

If you'd like to reach us directly with a bug report, please email us at [admin@daimo.xyz](mailto:admin@daimo.xyz).
